# Popup Launcher — Build Fix Report

## Root cause fixed
The previous `IShellCommandService.aidl` used the `in` direction modifier before `String` parameters, for example `in String targetPackage` and `in String packageName`.

Android AIDL treats `String` and primitive types as input by default and does not allow an explicit `in` modifier for them. Arrays such as `String[]` do require a direction marker. The fixed contract therefore keeps `in String[] command` and removes `in` from all plain `String`/primitive parameters.

## Files changed
- `app/src/main/aidl/com/example/popuplauncher/IShellCommandService.aidl`
- `app/src/main/java/com/example/popuplauncher/ShellCommandService.kt`
- `app/build.gradle.kts` — explicitly pins Android Build Tools 35.0.0 and enables AIDL.
- `.github/workflows/main.yml` — keeps Gradle cache disabled for ZIP-extracted projects and runs `:app:compileDebugAidl` before Lint.

## Compatibility
The AIDL contract retains the existing Shizuku reserved destroy transaction `16777114`.
The existing specialized operations remain available: `execCommand`, `launchFreeformPopup`, `killAppProcess`, and `trimBackgroundProcesses`.
