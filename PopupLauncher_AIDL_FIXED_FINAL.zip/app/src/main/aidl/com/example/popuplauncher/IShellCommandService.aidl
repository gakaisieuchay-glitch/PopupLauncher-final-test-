package com.example.popuplauncher;

/**
 * Shizuku UserService Binder contract.
 *
 * Note: AIDL primitives and String are implicitly "in" and must NOT be preceded
 * by the "in" direction marker. Arrays/other non-primitive values need a
 * direction marker, therefore String[] below correctly uses "in".
 */
interface IShellCommandService {

    /** Execute an argv-style shell command and return its exit code. */
    int execCommand(in String[] command);

    /**
     * Start an activity in Freeform (windowing mode 5) and optionally resize the task.
     * Bounds are supplied in screen-space pixels.
     */
    int launchFreeformPopup(
        String targetPackage,
        String targetActivity,
        int left,
        int top,
        int right,
        int bottom
    );

    /** Force-stop one application package. */
    boolean killAppProcess(String packageName);

    /** Ask ActivityManager to reclaim currently idle/cached processes. */
    boolean trimBackgroundProcesses();

    /** Reserved Shizuku UserService destroy transaction. */
    void destroy() = 16777114;
}
