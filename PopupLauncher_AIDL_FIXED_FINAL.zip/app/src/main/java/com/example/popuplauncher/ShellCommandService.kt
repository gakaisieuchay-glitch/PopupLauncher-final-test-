package com.example.popuplauncher

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

/**
 * Shizuku UserService running in its own process/identity (shell or root).
 * The Binder methods are synchronous by contract; child-process I/O is drained off the
 * Binder thread pool and never touches the application Main thread.
 */
class ShellCommandService : IShellCommandService.Stub() {

    companion object {
        private const val TAG = "ShellCommandService"
        private const val WINDOWING_MODE_FREEFORM = 5
        private const val COMMAND_TIMEOUT_MS = 4_000L
        private const val DUMPSYS_TIMEOUT_MS = 1_200L
        private const val TASK_LOOKUP_ATTEMPTS = 4
        private const val TASK_LOOKUP_RETRY_DELAY_MS = 150L
        private val COMPONENT_REGEX = Regex("""^[A-Za-z0-9_.$]+/[A-Za-z0-9_.$]+$""")
        private val PACKAGE_NAME_REGEX = Regex("""^[A-Za-z0-9_.$]+$""")
    }

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(serviceJob + Dispatchers.IO)

    override fun execCommand(command: Array<String>): Int =
        runIoBlocking { executeCommand(command, COMMAND_TIMEOUT_MS).first }

    override fun launchFreeformPopup(
        targetPackage: String,
        targetActivity: String,
        left: Int,
        top: Int,
        right: Int,
        bottom: Int
    ): Int = runIoBlocking {
        val component = "$targetPackage/$targetActivity"
        if (!COMPONENT_REGEX.matches(component)) {
            Log.w(TAG, "Invalid component: $component")
            return@runIoBlocking -1
        }

        val start = executeCommand(
            arrayOf(
                "am", "start", "-n", component,
                "--windowingMode", WINDOWING_MODE_FREEFORM.toString()
            ),
            COMMAND_TIMEOUT_MS
        )

        if (start.first != 0) {
            Log.w(TAG, "am start failed component=$component exit=${start.first}")
            return@runIoBlocking start.first
        }

        if ((right - left) > 0 && (bottom - top) > 0) {
            applyBoundsBestEffort(targetPackage, left, top, right, bottom)
        }

        start.first
    }

    override fun killAppProcess(packageName: String): Boolean = runIoBlocking {
        if (packageName.isBlank() || !PACKAGE_NAME_REGEX.matches(packageName)) {
            Log.w(TAG, "Invalid package for force-stop: $packageName")
            return@runIoBlocking false
        }
        executeCommand(arrayOf("am", "force-stop", packageName), COMMAND_TIMEOUT_MS).first == 0
    }

    override fun trimBackgroundProcesses(): Boolean = runIoBlocking {
        executeCommand(arrayOf("am", "kill-all"), COMMAND_TIMEOUT_MS).first == 0
    }

    private suspend fun applyBoundsBestEffort(
        targetPackage: String,
        left: Int,
        top: Int,
        right: Int,
        bottom: Int
    ) {
        repeat(TASK_LOOKUP_ATTEMPTS) { index ->
            val dump = executeCommand(
                arrayOf("dumpsys", "activity", "activities"),
                DUMPSYS_TIMEOUT_MS
            )
            val taskId = findTaskId(dump.second, targetPackage)
            if (taskId != null) {
                val boundsArg = "$left,$top,$right,$bottom"
                val resize = executeCommand(
                    arrayOf("am", "task", "resize", taskId.toString(), boundsArg),
                    COMMAND_TIMEOUT_MS
                )
                Log.d(TAG, "am task resize id=$taskId bounds=$boundsArg exit=${resize.first}")
                return
            }
            if (index + 1 < TASK_LOOKUP_ATTEMPTS) {
                delay(TASK_LOOKUP_RETRY_DELAY_MS)
            }
        }
        Log.w(TAG, "TaskRecord not found for $targetPackage; bounds resize skipped")
    }

    private fun findTaskId(dumpsysOutput: String, packageName: String): Int? {
        val regex = Regex("""#(\d+)\s+A=${Regex.escape(packageName)}\b""")
        return regex.findAll(dumpsysOutput)
            .lastOrNull()
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
    }

    private suspend fun executeCommand(
        command: Array<String>,
        timeoutMs: Long
    ): Pair<Int, String> = withContext(serviceScope.coroutineContext) {
        try {
            coroutineScope {
                val process = ProcessBuilder(*command)
                    .redirectErrorStream(true)
                    .start()

                val outputJob = async(Dispatchers.IO) {
                    process.inputStream.bufferedReader().use { it.readText() }
                }

                val completed = withTimeoutOrNull(timeoutMs + 250L) {
                    process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
                } ?: false

                if (!completed) {
                    process.destroy()
                    if (process.isAlive) process.destroyForcibly()
                    outputJob.cancel()
                    return@coroutineScope -1 to ""
                }

                val output = outputJob.await()
                process.exitValue() to output
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Shell command failed: ${t.message}", t)
            -1 to ""
        }
    }

    private fun <T> runIoBlocking(block: suspend () -> T): T =
        runBlocking {
            withContext(serviceScope.coroutineContext) {
                block()
            }
        }

    override fun destroy() {
        Log.d(TAG, "UserService destroy")
        serviceScope.cancel()
        serviceJob.cancel()
        exitProcess(0)
    }
}
