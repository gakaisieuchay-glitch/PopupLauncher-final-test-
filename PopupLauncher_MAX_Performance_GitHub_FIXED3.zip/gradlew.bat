@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "APP_HOME=%~dp0"
set "GRADLE_VERSION=8.9"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_HOME=%GRADLE_USER_HOME%\popup-wrapper\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat"

if not exist "%GRADLE_BIN%" (
    echo Downloading Gradle %GRADLE_VERSION%...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "^$ErrorActionPreference='Stop'; New-Item -ItemType Directory -Force -Path '%GRADLE_USER_HOME%\popup-wrapper' ^| Out-Null; Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_USER_HOME%\popup-wrapper\gradle-%GRADLE_VERSION%-bin.zip'; Expand-Archive -Force '%GRADLE_USER_HOME%\popup-wrapper\gradle-%GRADLE_VERSION%-bin.zip' '%GRADLE_USER_HOME%\popup-wrapper'; Remove-Item '%GRADLE_USER_HOME%\popup-wrapper\gradle-%GRADLE_VERSION%-bin.zip'; if (Test-Path '%GRADLE_HOME%') { }"
    if errorlevel 1 exit /b 1
)

cd /d "%APP_HOME%"
call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
