# Phase 3 – Performance & Utility

- Rebuilt `ShizukuManager.kt` as the single Shizuku gateway; Root -> Shizuku -> Native fallback.
- UserService connection is pooled for 8 seconds and unbound/destroyed on idle or panel teardown.
- Added `OverlayRenderOptimizer`: hardware layer is enabled only after drag threshold and removed on UP/CANCEL/remove.
- Removed duplicate `WindowManager.updateViewLayout()` call.
- Added `PopupLauncherTileService` for one-tap start/stop of the floating launcher.
- Kept features intentionally narrow: no extra analytics, network services, notification listeners, overlays or libraries.

## Build note
The source was statically checked in this environment, but Gradle 8.9 could not be downloaded because outbound DNS/network access is unavailable. CI workflow remains the authoritative build path.
