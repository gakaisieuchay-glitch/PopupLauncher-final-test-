# AIDL Binder contract and Shizuku UserService entry point.
# Shizuku instantiates the UserService by class name, so both name and members
# must survive shrinking/obfuscation.
-keep interface com.example.popuplauncher.IShellCommandService { *; }
-keep class com.example.popuplauncher.IShellCommandService$Stub { *; }
-keep class com.example.popuplauncher.ShellCommandService { *; }
-keepnames class com.example.popuplauncher.ShellCommandService

# Shizuku Binder/provider/runtime classes are reflection- and Binder-driven.
-keep class rikka.shizuku.** { *; }
-keep interface rikka.shizuku.** { *; }
-keep class dev.rikka.shizuku.** { *; }
-keep interface dev.rikka.shizuku.** { *; }

# Android framework/annotation metadata used by Binder/reflective APIs.
-keepattributes *Annotation*
-keepattributes InnerClasses,EnclosingMethod

# Application Services referenced from AndroidManifest.xml.
-keep class com.example.popuplauncher.FloatingService { *; }
-keep class com.example.popuplauncher.PopupLauncherApplication { *; }

# RootManager / ShizukuManager thực thi shell command dựa trên tên gói + tên Activity
# lấy từ PackageManager tại runtime; giữ nguyên để logic Priority Launch Engine
# (Root -> Shizuku -> ActivityOptions) không bị đổi hành vi khi minify.
-keep class com.example.popuplauncher.RootManager { *; }
-keep class com.example.popuplauncher.ShizukuManager { *; }

# WindowSizePreset (Window Size Presets + Per-App Layout Memory): AppListHelper lưu và đọc lại
# preset đã chọn cho từng app bằng WindowSizePreset.name (String) qua SharedPreferences, rồi
# tra ngược bằng fromNameSafe(). Nếu R8 đổi tên các hằng số enum, dữ liệu Per-App Layout Memory
# đã lưu trên máy người dùng ở phiên bản trước sẽ không còn khớp được nữa (không crash, nhưng
# app coi như "quên" hết lựa chọn kích thước cũ). -keepclassmembers cho values()/valueOf() theo
# đúng khuyến nghị của R8 cho enum, cộng thêm -keepnames để giữ đúng tên từng hằng số.
-keep class com.example.popuplauncher.WindowSizePreset { *; }
-keepclassmembers enum com.example.popuplauncher.WindowSizePreset {
    public static **[] values();
    public static ** valueOf(java.lang.String);
    <fields>;
}

# Manifest-referenced Quick Settings Tile entry point.
-keep class com.example.popuplauncher.service.PopupLauncherTileService { *; }
