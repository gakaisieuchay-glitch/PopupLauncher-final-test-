package com.example.popuplauncher

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.Intent
import android.content.IntentFilter
import android.content.Context
import com.example.popuplauncher.cache.IconCache

class PopupLauncherApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        ShizukuManager.initialize(this)

        // Package changes invalidate the icon/catalog fast paths without keeping a long-lived
        // exported receiver or polling the PackageManager.
        val packageReceiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(context: android.content.Context, intent: Intent) {
                IconCache.clear()
                AppListHelper.invalidateCatalogCache()
            }
        }
        val packageFilter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(packageReceiver, packageFilter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(packageReceiver, packageFilter)
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ||
            level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN
        ) {
            IconCache.clear()
        }
    }
}
