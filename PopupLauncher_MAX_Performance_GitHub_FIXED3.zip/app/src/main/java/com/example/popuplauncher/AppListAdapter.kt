package com.example.popuplauncher

import android.graphics.Color
import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.popuplauncher.cache.IconCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * RecyclerView adapter deliberately avoids holding Drawable/Bitmap references in
 * the backing list. Icons are resolved only for visible rows and cleared on recycle.
 *
 * Icon loading is now cache-first + async: [IconCache.getCached] is a synchronous,
 * in-memory lookup (safe to call from onBindViewHolder), and only falls back to a
 * coroutine (via [iconLoader]) on a genuine cache miss. Each pending load is tagged
 * on the icon ImageView and cancelled on recycle/rebind so a slow load for a row that
 * has since scrolled away can never paint over the wrong item.
 */
class AppListAdapter(
    initialItems: List<AppEntry>,
    private val scope: CoroutineScope,
    private val iconLoader: suspend (AppEntry) -> android.graphics.drawable.Drawable?,
    private val onItemClick: (AppEntry) -> Unit,
    private val onItemLongClick: (AppEntry) -> Unit
) : ListAdapter<AppEntry, AppListAdapter.AppViewHolder>(DIFF_CALLBACK) {

    class AppViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(ICON_ID)
        val label: TextView = view.findViewById(LABEL_ID)
        val favoriteBadge: ImageView = view.findViewById(BADGE_ID)

        companion object {
            const val ICON_ID = 1001
            const val LABEL_ID = 1002
            const val BADGE_ID = 1003
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val context = parent.context
        val density = context.resources.displayMetrics.density

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val paddingPx = (12 * density).toInt()
            setPadding(paddingPx, paddingPx, paddingPx, paddingPx)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            isClickable = true
            isFocusable = true
        }

        val iconContainer = FrameLayout(context)
        val icon = ImageView(context).apply {
            id = AppViewHolder.ICON_ID
            layoutParams = FrameLayout.LayoutParams(
                (40 * density).toInt(),
                (40 * density).toInt()
            )
        }

        val badge = ImageView(context).apply {
            id = AppViewHolder.BADGE_ID
            layoutParams = FrameLayout.LayoutParams(
                (14 * density).toInt(),
                (14 * density).toInt(),
                Gravity.BOTTOM or Gravity.END
            )
            setImageResource(android.R.drawable.star_big_on)
            visibility = View.GONE
        }

        iconContainer.addView(icon)
        iconContainer.addView(badge)

        val label = TextView(context).apply {
            id = AppViewHolder.LABEL_ID
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.NORMAL)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            ).apply { marginStart = (12 * density).toInt() }
            maxLines = 1
        }

        root.addView(iconContainer)
        root.addView(label)
        return AppViewHolder(root)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        val entry = getItem(position)

        // Identity tag so a coroutine that resolves late (row scrolled away and got
        // rebound to a different app in the meantime) can tell it's now stale.
        holder.itemView.tag = entry.packageName

        cancelPendingLoad(holder)

        val cached = IconCache.getCached(entry)
        holder.icon.setImageDrawable(cached)
        if (cached == null) {
            holder.icon.tag = scope.launch {
                val drawable = iconLoader(entry)
                if (holder.itemView.tag == entry.packageName) {
                    holder.icon.setImageDrawable(drawable)
                }
            }
        }

        holder.label.text = entry.label
        holder.favoriteBadge.visibility =
            if (entry.isFavorite) View.VISIBLE else View.GONE

        holder.itemView.setOnClickListener { onItemClick(entry) }
        holder.itemView.setOnLongClickListener {
            onItemLongClick(entry)
            true
        }
    }

    override fun onViewRecycled(holder: AppViewHolder) {
        // Drop strong Drawable references immediately when a row leaves the pool,
        // and cancel any in-flight icon load so it can't paint a recycled row later.
        cancelPendingLoad(holder)
        holder.icon.setImageDrawable(null)
        holder.itemView.tag = null
        holder.itemView.setOnClickListener(null)
        holder.itemView.setOnLongClickListener(null)
        super.onViewRecycled(holder)
    }

    private fun cancelPendingLoad(holder: AppViewHolder) {
        (holder.icon.tag as? Job)?.cancel()
        holder.icon.tag = null
    }

    fun updateData(newItems: List<AppEntry>) {
        submitList(newItems)
    }

    fun clearReferences() {
        submitList(emptyList())
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<AppEntry>() {
            override fun areItemsTheSame(oldItem: AppEntry, newItem: AppEntry): Boolean =
                oldItem.packageName == newItem.packageName &&
                    oldItem.activityName == newItem.activityName

            override fun areContentsTheSame(oldItem: AppEntry, newItem: AppEntry): Boolean =
                oldItem.packageName == newItem.packageName &&
                    oldItem.activityName == newItem.activityName &&
                    oldItem.label == newItem.label &&
                    oldItem.isFavorite == newItem.isFavorite
        }
    }
}
