package com.example.popuplauncher.service

import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.example.popuplauncher.FloatingService
import com.example.popuplauncher.R

/** Minimal QS control: one tap to show/hide the launcher bubble, no duplicate state store. */
class PopupLauncherTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTileState()
    }

    override fun onClick() {
        super.onClick()
        val running = FloatingService.isRunning
        val intent = Intent(this, FloatingService::class.java).apply {
            action = if (running) FloatingService.ACTION_STOP else FloatingService.ACTION_START
        }

        if (running) {
            startService(intent)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        qsTile?.state = if (!running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        qsTile?.updateTile()
    }

    private fun updateTileState() {
        val tile = qsTile ?: return
        tile.state = if (FloatingService.isRunning) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = getString(R.string.app_name)
        tile.contentDescription = getString(R.string.floating_service_label)
        tile.icon = Icon.createWithResource(this, R.drawable.ic_launcher_foreground)
        tile.updateTile()
    }
}
