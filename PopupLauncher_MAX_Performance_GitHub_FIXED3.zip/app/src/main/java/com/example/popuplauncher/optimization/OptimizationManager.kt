package com.example.popuplauncher.optimization

import android.app.ActivityManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import com.example.popuplauncher.IShellCommandService
import com.example.popuplauncher.RootManager
import com.example.popuplauncher.ShizukuManager
import com.example.popuplauncher.cache.IconCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * "Super Boost": an explicit, user-toggled optimization mode, not something that runs on
 * its own. Every privileged command here is a standard, publicly documented adb-shell
 * command (`am`, `cmd package`, `sm`, `settings`) run with privilege the app already
 * negotiated for its Priority Launch Engine (Root, else Shizuku) — nothing here escalates
 * beyond what launching a floating window already needs, and it only ever touches this
 * device (no network, no other app's data).
 *
 * Routed Root-first, then Shizuku — the same order as [ShizukuManager.launchPopup] — so a
 * rooted device never needs to spin up a Shizuku UserService just to run a boost command.
 *
 * Known trade-off, called out rather than hidden: `am kill-all` is a blunt instrument. It
 * asks the system to reclaim idle/cached background processes right now instead of waiting
 * for real memory pressure — the same thing Android already does on its own, just earlier
 * and on demand. It will not stop an app actively doing work (music playback, a foreground
 * service), but it CAN end an idle background process, which may briefly delay something
 * like a chat app's next push notification. If that trade-off isn't wanted for a specific
 * app, [IShellCommandService.killAppProcess] (single, named package via `am force-stop`) is
 * the narrower alternative already wired into `ShellCommandService`.
 */
class OptimizationManager(private val context: Context) {

    data class OptimizationResult(
        val isFullySuccess: Boolean,
        val logs: List<String>
    )

    suspend fun enableSuperBoost(): OptimizationResult = withContext(Dispatchers.IO) {
        val logs = mutableListOf<String>()
        var successCount = 0
        var privilegedAttempts = 0

        // 1. App's own RAM — always available, no Root/Shizuku needed.
        runCatching {
            IconCache.clear()
            logs.add("✓ Đã dọn Icon Cache (RAM) của Pop-up Launcher")
            successCount++
        }

        if (!RootManager.hasRootAccess() && !ShizukuManager.hasShizukuPermission()) {
            logs.add("⚠ Không có quyền Root/Shizuku — chỉ dọn được RAM của riêng app này.")
            return@withContext OptimizationResult(isFullySuccess = false, logs = logs)
        }

        // 2. Thu hồi tiến trình nền đang rảnh trên toàn hệ thống.
        privilegedAttempts++
        if (runPrivileged("am kill-all") { it.trimBackgroundProcesses() }) {
            logs.add("✓ Đã giải phóng RAM ứng dụng nền đang rảnh (am kill-all)")
            successCount++
        } else {
            logs.add("⚠ Lệnh am kill-all thất bại (ROM có thể chặn)")
        }

        // Do NOT run bg-dexopt-job or fstrim here: both can cause CPU/I/O contention
        // while the user is about to enter a game, which is the opposite of a low-latency boost.
        logs.add("• Bỏ qua ART dexopt/fstrim: không đưa I/O nặng vào đường nóng của game.")

        // We also do not force peak_refresh_rate. Android/OEM policy may ignore it, and
        // pinning the panel to a higher rate can increase power/thermal load on low-end devices.

        logs.add("➔ RAM khả dụng hiện tại: ${getFreeRamMb()}MB")

        OptimizationResult(
            isFullySuccess = privilegedAttempts == 0 || successCount >= privilegedAttempts,
            logs = logs
        )
    }

    /** Trả lại tần số quét tự động cho hệ thống. Không đụng đến RAM/Icon cache đã dọn. */
    suspend fun disableSuperBoost() = withContext(Dispatchers.IO) {
        runPrivileged("settings delete system peak_refresh_rate") { service ->
            service.execCommand(arrayOf("settings", "delete", "system", "peak_refresh_rate"))
            service.execCommand(arrayOf("settings", "delete", "system", "min_refresh_rate"))
            true
        }
    }

    /**
     * Root first, else Shizuku — same priority order as the launch engine.
     * [rootCommand] is the one-line shell command for the Root path; [viaShizuku] does the
     * same thing through the typed AIDL service for the Shizuku path.
     */
    private suspend fun runPrivileged(
        rootCommand: String,
        viaShizuku: suspend (IShellCommandService) -> Boolean
    ): Boolean {
        if (RootManager.hasRootAccess()) {
            return RootManager.runCommand(rootCommand)
        }
        if (ShizukuManager.hasShizukuPermission()) {
            return ShizukuManager.withShellService(context) { viaShizuku(it) } == true
        }
        return false
    }

    private fun highestSupportedRefreshRate(): Float = runCatching {
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
        display?.supportedModes?.maxOfOrNull { it.refreshRate } ?: 60f
    }.getOrDefault(60f)

    private fun getFreeRamMb(): Long {
        val activityManager =
            context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return 0
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.availMem / (1024 * 1024)
    }
}
