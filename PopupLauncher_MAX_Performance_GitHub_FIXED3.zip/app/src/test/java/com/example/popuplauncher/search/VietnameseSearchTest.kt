package com.example.popuplauncher.search

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VietnameseSearchTest {

    @Test
    fun normalize_handles_vietnamese_diacritics_and_d() {
        assertTrue(VietnameseSearch.normalize("Đặng") == "dang")
        assertTrue(VietnameseSearch.normalize("Ứng dụng") == "ung dung")
    }

    @Test
    fun matches_supports_accent_insensitive_name() {
        assertTrue(VietnameseSearch.matches("nhan", "Nhắn Tin", "com.example.chat"))
    }

    @Test
    fun matches_supports_initials_and_package_name() {
        assertTrue(VietnameseSearch.matches("nt", "Nhắn Tin", "com.example.chat"))
        assertTrue(VietnameseSearch.matches("example", "Ứng dụng", "com.example.example"))
        assertFalse(VietnameseSearch.matches("camera", "Nhắn Tin", "com.example.chat"))
    }

    @Test
    fun precomputed_key_matches_without_re_normalizing_each_item() {
        val key = VietnameseSearch.buildKey("Cài đặt", "com.android.settings")
        assertTrue(VietnameseSearch.matchesNormalized("cai", key))
        assertTrue(VietnameseSearch.matchesNormalized("set", key))
        assertTrue(VietnameseSearch.matchesNormalized("android", key))
        assertFalse(VietnameseSearch.matchesNormalized("camera", key))
    }
}
